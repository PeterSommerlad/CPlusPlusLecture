#include "TestBoundedQueueAPI.h"
#include "BoundedQueue.h"
#include "cute.h"



cute::suite make_suite_TestBoundedQueueAPI(){
	cute::suite s;
	return s;
}



