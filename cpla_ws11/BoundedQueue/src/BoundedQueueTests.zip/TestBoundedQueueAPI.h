#include "cute_suite.h"

extern cute::suite make_suite_TestBoundedQueueAPI();
